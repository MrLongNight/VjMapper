#!/bin/sh
set -o verbose
# Convert markdown file to html
markdown docs/informations/osc.md > docs/informations/osc.html
