#!/bin/bash
# doxygen
doxygen Doxyfile
