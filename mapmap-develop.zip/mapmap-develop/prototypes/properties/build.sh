#!/bin/bash
# qt4-default qt4-qmake
qmake-qt4
make
