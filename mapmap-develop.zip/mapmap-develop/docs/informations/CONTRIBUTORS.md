## Authors

- Sofian Audry: lead developer, user interface designer, project
    manager.
- Dame Diongue: developer.
- Alexandre Quessy: release manager, developer, technical writer,
    project manager.
- Mike Latona: user interface designer.
- Vasilis Liaskovitis: developer.

&nbsp;

## Contributors

- Lucas Adair : developer, macOS packaging.
- Christian Ambaud: sponsor, inspiration.
- Alex Barry: user experience design.
- Eliza Bennett : documentation, chinese translation.
- Jonathan Roman Bland : developer.
- Sylvain Cormier: developer.
- Maxime Damecour: inspiration.
- Louis Desjardins: project manager.
- Ian Donnelly : user interface designer, documentation.
- Gene Felice : video package, documentation.
- Julien Keable: developer.
- Marc Lavallée: help with packaging.
- Matthew Loewens : documentation, developer.
- Madison Suniga : documentation.

&nbsp;
