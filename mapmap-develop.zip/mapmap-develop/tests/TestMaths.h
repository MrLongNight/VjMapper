#include <QtTest/QtTest>

class TestMaths: public QObject
{
    Q_OBJECT

    private slots:
        void toUpper();
};

